package jspServlet.vo;

public class User {
	private String administratorid;
	private String administratorkey;
	private String name;
	public String getAdministratorid() {
		return administratorid;
	}
	public void setAdministratorid(String administratorid) {
		this.administratorid = administratorid;
	}
	public String getAdministratorkey() {
		return administratorkey;
	}
	public void setAdministratorkey(String administratorkey) {
		this.administratorkey = administratorkey;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
