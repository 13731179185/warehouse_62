package jspServlet.vo;

public class User_off {
	private String administratoridoff;
	private String administratorkeyoff;
	private String nameoff;
	
	public String getAdministratoridoff() {
		return administratoridoff;
	}
	public void setAdministratoridoff(String administratoridoff) {
		this.administratoridoff = administratoridoff;
	}
	public String getAdministratorkeyoff() {
		return administratorkeyoff;
	}
	public void setAdministratorkeyoff(String administratorkeyoff) {
		this.administratorkeyoff = administratorkeyoff;
	}
	public String getNameoff() {
		return nameoff;
	}
	public void setNameoff(String nameoff) {
		this.nameoff = nameoff;
	}
}
