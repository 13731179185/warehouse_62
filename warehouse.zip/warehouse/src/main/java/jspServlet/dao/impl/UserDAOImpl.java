package jspServlet.dao.impl;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.resource.cci.ResultSet;

import jspServlet.dao.Userdao;
import jspServlet.db.DBConnect;
import jspServlet.vo.User;
import jspServlet.vo.User_off;

public class UserDAOImpl implements Userdao {
	//判断密码函数
	public int queryByUsername(User user) throws Exception{
		int flag=0;
		String sql="select * from administrator where administratorid=?";
		String sql_delete = "delete from administrator where administratorid=?";
		PreparedStatement pstmt = null;
		DBConnect dbc = null;
		
		try {
		//	System.out.println("-----------");
			dbc = new DBConnect();
		//	System.out.println("++++++++");
			pstmt = dbc.getConnection().prepareStatement(sql);
			pstmt.setString(1, user.getAdministratorid());
			java.sql.ResultSet rs =  pstmt.executeQuery();
			if(rs.next()) {
				if(rs.getString("administratorkey").equals(user.getAdministratorkey())){
					flag = 1;
				    
				//	System.out.println(flag);
				}
			}
			rs.close();
			pstmt.close();
		}catch(SQLException e) {
			System.out.println(e.getMessage());
			//System.out.println("123");
		}finally {
			dbc.close();
		}
		return flag;
	}
	public int queryByUsernameoff(User_off useroff) throws Exception{
		int flag=0;
		String sql="select * from administrator where administratorid=?";
		PreparedStatement pstmt = null;
		DBConnect dbc = null;
		
		try {
		//	System.out.println("-----------");
			dbc = new DBConnect();
		//	System.out.println("++++++++");
			pstmt = dbc.getConnection().prepareStatement(sql);
			pstmt.setString(1, useroff.getAdministratoridoff());
			java.sql.ResultSet rs =  pstmt.executeQuery();
			if(rs.next()) {
				if(rs.getString("administratorkey").equals(useroff.getAdministratorkeyoff())){
					flag = 1;
				    
				//	System.out.println(flag);
				}
			}
			rs.close();
			pstmt.close();
		}catch(SQLException e) {
			System.out.println(e.getMessage());
			//System.out.println("123");
		}finally {
			dbc.close();
		}
		return flag;
	}
	//显示管理员名字函数
	public String queryByUsername1(User user) throws Exception{
		int flag=0;
		String sql="select * from administrator where administratorid=?";
		PreparedStatement pstmt = null;
		DBConnect dbc = null;
		String name = "";
		
		try {
		//	System.out.println("-----------");
			dbc = new DBConnect();
		//	System.out.println("++++++++");
			pstmt = dbc.getConnection().prepareStatement(sql);
			pstmt.setString(1, user.getAdministratorid());
			java.sql.ResultSet rs =  pstmt.executeQuery();
			if(rs.next()) {
				if(rs.getString("administratorkey").equals(user.getAdministratorkey())){
					flag = 1;
				    name = rs.getString("name"); 
				//	System.out.println(flag);
				}
			}
			rs.close();
			pstmt.close();
		}catch(SQLException e) {
			System.out.println(e.getMessage());
			//System.out.println("123");
		}finally {
			dbc.close();
		}
		return name;
	}
	//注销函数
	public void queryByUsername2(User_off useroff) throws Exception{

		String sql_delete = "delete from administrator where administratorid=?";
		DBConnect dbc = null;
	    PreparedStatement pstmt0 = null;
		try {
		//	System.out.println("-----------");
			dbc = new DBConnect();
		//	System.out.println("++++++++");
			pstmt0 = dbc.getConnection().prepareStatement(sql_delete);
			pstmt0.setString(1, useroff.getAdministratoridoff());
			pstmt0.executeUpdate();
			pstmt0.close();
		}catch(SQLException e) {
			System.out.println(e.getMessage());
			//System.out.println("123");
		}finally {
			dbc.close();
		}
	}
}

