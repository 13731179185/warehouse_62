package jspServlet.dao;

import jspServlet.vo.User;
import jspServlet.vo.User_off;

public interface Userdao {
	public int queryByUsername (User user) throws Exception;
	public int queryByUsernameoff (User_off useroff) throws Exception;
	public String queryByUsername1 (User user) throws Exception;
    public void queryByUsername2 (User_off useroff) throws Exception;
}
