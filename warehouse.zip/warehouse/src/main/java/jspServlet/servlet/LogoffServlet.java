package jspServlet.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jspServlet.dao.Userdao;
import jspServlet.dao.impl.UserDAOImpl;
import jspServlet.vo.User_off;

public class LogoffServlet extends HttpServlet{
	
	public void doGet(HttpServletRequest req, HttpServletResponse res)
	    throws IOException, ServletException{
}
	
	public void doPost(HttpServletRequest req, HttpServletResponse res)
	    throws IOException, ServletException{
		User_off useroff = new User_off();
		useroff.setAdministratoridoff(req.getParameter("administratoridoff"));
		useroff.setAdministratorkeyoff(req.getParameter("administratorkeyoff"));
		
		Userdao dao = new UserDAOImpl();
		int flag = 0;
		String name = "";
		try {
			flag = dao.queryByUsernameoff(useroff);
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		if(flag==1) {
		    try {
				dao.queryByUsername2(useroff);
				res.sendRedirect("./login.jsp");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		else {
			System.out.println("账号密码错误");
		}
	}
}
