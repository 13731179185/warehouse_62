package jspServlet.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jspServlet.dao.Userdao;
import jspServlet.dao.impl.UserDAOImpl;
import jspServlet.vo.User;

public class LoginServlet extends HttpServlet {
	
	public void doGet(HttpServletRequest req, HttpServletResponse res)
	    throws IOException, ServletException{
}
	
	public void doPost(HttpServletRequest req, HttpServletResponse res)
	    throws IOException, ServletException{
		User user = new User();
		user.setAdministratorid(req.getParameter("administratorid"));
		user.setAdministratorkey(req.getParameter("administratorkey"));
		
		Userdao dao = new UserDAOImpl();
		int flag = 0;
		String name = "";
		try {
			    flag = dao.queryByUsername(user);
			    name = dao.queryByUsername1(user);
		}catch(Exception e) {
			e.printStackTrace();
		}
		if(flag==1) {
		//	System.out.println(flag);
			HttpSession session = req.getSession();
			session.setAttribute("administratorid", user.getAdministratorid());
			session.setAttribute("name",name);
			res.sendRedirect("./welcome.jsp");
		}
		else {
			res.sendRedirect("./error.jsp");
		}
	}
}
