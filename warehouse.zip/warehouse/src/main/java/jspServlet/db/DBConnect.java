package jspServlet.db;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnect {
	private final String DBDRIVER = "com.mysql.cj.jdbc.Driver";
  //  private final String DBURL = "jdbc:mysql://1270.0.0.1:3306/JavaWebDB";
  //  private final String DBUSER = "root";
   // private final String DBPASSWORD = "123456";
	private Connection conn = null;
    
    public DBConnect() {
    	try {
    	//	System.out.println("-------");
    		Class.forName(DBDRIVER);
    	//	System.out.println("++++++++++");//没有
    		//this.conn = DriverManager.getConnection(DBURL,DBUSER,DBPASSWORD);
    		this.conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/warehouse?useSSL=false&serverTimezone=UTC","root","123456");
    	}catch(Exception e) {
    		System.out.println(e.getMessage());
    	}
    }
    
    public Connection getConnection() {
    	return this.conn;
    }
    
    public void close() {
    	try {
    		this.conn.close();
    	}catch(Exception e) {}
}
}
